package domini;

public class Terme extends Node{

	private static final long serialVersionUID = 6823608949299302327L;
	
	public Terme(){
		super();
	}
	public Terme(int id, String nom) {
		super(id,nom);
	}
}
