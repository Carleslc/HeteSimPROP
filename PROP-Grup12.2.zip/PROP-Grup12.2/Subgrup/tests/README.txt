Per provar un driver feu servir:
java -jar driver.jar

Totes les classes necessaries per executar-se (driver, classe a provar i stubs) estan incloses al jar.
